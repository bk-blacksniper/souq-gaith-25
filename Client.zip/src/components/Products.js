// src/components/Products.js
import { useEffect, useState } from "react"
import { supabase } from "../lib/supabaseClient"   // انتبه للمسار
import Products2 from "./Products2"

export default function Products() {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true)

      const { data, error } = await supabase
        .from("products")
        .select("*")
        .order("created_at", { ascending: false })

      if (error) {
        console.error(error)
        setError(error.message)
      } else {
        setProducts(data)
      }

      setLoading(false)
    }

    fetchProducts()
  }, [])

  if (loading) {
    return <p className="text-center p-4">جاري تحميل المنتجات...</p>
  }

  if (error) {
    return (
      <p className="text-center p-4 text-red-600">
        حدث خطأ أثناء جلب المنتجات: {error}
      </p>
    )
  }

  if (products.length === 0) {
    return <p className="text-center p-4">لا يوجد منتجات حاليًا.</p>
  }

  // هنا نمرّر المنتجات إلى الكومبوننت الثاني
  return <Products2 products={products} />
}
