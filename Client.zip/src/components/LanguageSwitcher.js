import React from "react";
import { useTranslation } from "react-i18next";

export default function LanguageSwitcher({ className = "" }) {
  const { i18n } = useTranslation();
  const isEn = i18n.language?.startsWith("en");

  const toggle = () => {
    i18n.changeLanguage(isEn ? "ar" : "en");
  };

  return (
    <button
      type="button"
      className={`btn btn-sm ${isEn ? "btn-outline-success" : "btn-outline-light"} ${className}`}
      onClick={toggle}
      title="Change language"
    >
      {isEn ? "AR" : "EN"}
    </button>
  );
}
